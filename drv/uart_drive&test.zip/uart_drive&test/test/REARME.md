aarch64-linux-gnu-gcc uart_test.c -o uart_test



use:

./uart_test 0 -b 115200 -p odd